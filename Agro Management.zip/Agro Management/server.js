import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, 'public')));

// Configuração do MySQL
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'agroindustria_db',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Função para executar queries
async function query(sql, values = []) {
  try {
    const connection = await pool.getConnection();
    const [results] = await connection.execute(sql, values);
    connection.release();
    return results;
  } catch (error) {
    console.error('Erro na query:', error);
    throw error;
  }
}

// Inicializar banco de dados
async function initializeDatabase() {
  try {
    // Criar tabelas
    await query(`
      CREATE TABLE IF NOT EXISTS raw_materials (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        unit VARCHAR(50) NOT NULL,
        current_stock DECIMAL(10, 2) DEFAULT 0,
        minimum_stock DECIMAL(10, 2) DEFAULT 0,
        maximum_stock DECIMAL(10, 2) DEFAULT 0,
        unit_cost DECIMAL(10, 2) DEFAULT 0,
        is_active BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS suppliers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255),
        phone VARCHAR(20),
        cnpj VARCHAR(20),
        address VARCHAR(255),
        city VARCHAR(100),
        state VARCHAR(50),
        is_active BOOLEAN DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS stock_entries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        raw_material_id INT NOT NULL,
        supplier_id INT,
        quantity DECIMAL(10, 2) NOT NULL,
        unit VARCHAR(50) NOT NULL,
        lot_number VARCHAR(100),
        entry_date DATE NOT NULL,
        expiry_date DATE,
        unit_cost DECIMAL(10, 2),
        total_cost DECIMAL(12, 2),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (raw_material_id) REFERENCES raw_materials(id),
        FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
      )
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS stock_movements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        raw_material_id INT NOT NULL,
        type VARCHAR(50) NOT NULL,
        quantity DECIMAL(10, 2) NOT NULL,
        unit VARCHAR(50) NOT NULL,
        reason VARCHAR(255),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (raw_material_id) REFERENCES raw_materials(id)
      )
    `);

    await query(`
      CREATE TABLE IF NOT EXISTS stock_alerts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        raw_material_id INT NOT NULL,
        alert_type VARCHAR(50) NOT NULL,
        message TEXT,
        is_resolved BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        resolved_at TIMESTAMP NULL,
        FOREIGN KEY (raw_material_id) REFERENCES raw_materials(id)
      )
    `);

    console.log('✅ Tabelas do banco de dados criadas/verificadas');
  } catch (error) {
    console.error('❌ Erro ao inicializar banco de dados:', error.message);
  }
}

// ==================== ROTAS DE MATÉRIAS-PRIMAS ====================

// Listar matérias-primas
app.get('/api/raw-materials', async (req, res) => {
  try {
    const results = await query('SELECT * FROM raw_materials ORDER BY name');
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obter matéria-prima por ID
app.get('/api/raw-materials/:id', async (req, res) => {
  try {
    const results = await query('SELECT * FROM raw_materials WHERE id = ?', [req.params.id]);
    res.json(results[0] || {});
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar matéria-prima
app.post('/api/raw-materials', async (req, res) => {
  try {
    const { name, category, unit, minimum_stock, maximum_stock, unit_cost } = req.body;
    const result = await query(
      'INSERT INTO raw_materials (name, category, unit, minimum_stock, maximum_stock, unit_cost) VALUES (?, ?, ?, ?, ?, ?)',
      [name, category, unit, minimum_stock, maximum_stock, unit_cost]
    );
    res.json({ id: result.insertId, ...req.body });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar matéria-prima
app.put('/api/raw-materials/:id', async (req, res) => {
  try {
    const { name, category, unit, minimum_stock, maximum_stock, unit_cost, is_active } = req.body;
    await query(
      'UPDATE raw_materials SET name = ?, category = ?, unit = ?, minimum_stock = ?, maximum_stock = ?, unit_cost = ?, is_active = ? WHERE id = ?',
      [name, category, unit, minimum_stock, maximum_stock, unit_cost, is_active, req.params.id]
    );
    res.json({ id: req.params.id, ...req.body });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deletar matéria-prima
app.delete('/api/raw-materials/:id', async (req, res) => {
  try {
    await query('DELETE FROM raw_materials WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== ROTAS DE FORNECEDORES ====================

// Listar fornecedores
app.get('/api/suppliers', async (req, res) => {
  try {
    const results = await query('SELECT * FROM suppliers ORDER BY name');
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar fornecedor
app.post('/api/suppliers', async (req, res) => {
  try {
    const { name, email, phone, cnpj, address, city, state } = req.body;
    const result = await query(
      'INSERT INTO suppliers (name, email, phone, cnpj, address, city, state) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name, email, phone, cnpj, address, city, state]
    );
    res.json({ id: result.insertId, ...req.body });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar fornecedor
app.put('/api/suppliers/:id', async (req, res) => {
  try {
    const { name, email, phone, cnpj, address, city, state, is_active } = req.body;
    await query(
      'UPDATE suppliers SET name = ?, email = ?, phone = ?, cnpj = ?, address = ?, city = ?, state = ?, is_active = ? WHERE id = ?',
      [name, email, phone, cnpj, address, city, state, is_active, req.params.id]
    );
    res.json({ id: req.params.id, ...req.body });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deletar fornecedor
app.delete('/api/suppliers/:id', async (req, res) => {
  try {
    await query('DELETE FROM suppliers WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== ROTAS DE ENTRADAS DE ESTOQUE ====================

// Listar entradas
app.get('/api/stock-entries', async (req, res) => {
  try {
    const results = await query(`
      SELECT se.*, rm.name as material_name, s.name as supplier_name
      FROM stock_entries se
      LEFT JOIN raw_materials rm ON se.raw_material_id = rm.id
      LEFT JOIN suppliers s ON se.supplier_id = s.id
      ORDER BY se.entry_date DESC
    `);
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar entrada de estoque
app.post('/api/stock-entries', async (req, res) => {
  try {
    const { raw_material_id, supplier_id, quantity, unit, lot_number, entry_date, expiry_date, unit_cost, notes } = req.body;
    const total_cost = quantity * (unit_cost || 0);

    const result = await query(
      'INSERT INTO stock_entries (raw_material_id, supplier_id, quantity, unit, lot_number, entry_date, expiry_date, unit_cost, total_cost, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [raw_material_id, supplier_id, quantity, unit, lot_number, entry_date, expiry_date, unit_cost, total_cost, notes]
    );

    // Atualizar estoque
    await query(
      'UPDATE raw_materials SET current_stock = current_stock + ? WHERE id = ?',
      [quantity, raw_material_id]
    );

    // Registrar movimento
    await query(
      'INSERT INTO stock_movements (raw_material_id, type, quantity, unit, reason) VALUES (?, ?, ?, ?, ?)',
      [raw_material_id, 'entrada', quantity, unit, 'Entrada de estoque']
    );

    res.json({ id: result.insertId, ...req.body });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== ROTAS DE MOVIMENTAÇÕES ====================

// Listar movimentações
app.get('/api/stock-movements', async (req, res) => {
  try {
    const results = await query(`
      SELECT sm.*, rm.name as material_name
      FROM stock_movements sm
      LEFT JOIN raw_materials rm ON sm.raw_material_id = rm.id
      ORDER BY sm.created_at DESC
    `);
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== ROTAS DE ALERTAS ====================

// Listar alertas
app.get('/api/stock-alerts', async (req, res) => {
  try {
    const results = await query(`
      SELECT sa.*, rm.name as material_name, rm.current_stock
      FROM stock_alerts sa
      LEFT JOIN raw_materials rm ON sa.raw_material_id = rm.id
      WHERE sa.is_resolved = 0
      ORDER BY sa.created_at DESC
    `);
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Gerar alertas de estoque baixo
app.post('/api/check-alerts', async (req, res) => {
  try {
    const materials = await query('SELECT * FROM raw_materials WHERE current_stock <= minimum_stock AND is_active = 1');
    
    for (const material of materials) {
      await query(
        'INSERT INTO stock_alerts (raw_material_id, alert_type, message) VALUES (?, ?, ?)',
        [material.id, 'low_stock', `Estoque baixo: ${material.name}`]
      );
    }

    res.json({ checked: materials.length });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ==================== ROTAS DE RELATÓRIOS ====================

// Relatório de movimentação
app.get('/api/reports/movements', async (req, res) => {
  try {
    const { startDate, endDate, materialId } = req.query;
    let sql = 'SELECT sm.*, rm.name as material_name FROM stock_movements sm LEFT JOIN raw_materials rm ON sm.raw_material_id = rm.id WHERE 1=1';
    const params = [];

    if (startDate) {
      sql += ' AND DATE(sm.created_at) >= ?';
      params.push(startDate);
    }
    if (endDate) {
      sql += ' AND DATE(sm.created_at) <= ?';
      params.push(endDate);
    }
    if (materialId) {
      sql += ' AND sm.raw_material_id = ?';
      params.push(materialId);
    }

    sql += ' ORDER BY sm.created_at DESC';

    const results = await query(sql, params);
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Relatório de inventário
app.get('/api/reports/inventory', async (req, res) => {
  try {
    const results = await query('SELECT * FROM raw_materials ORDER BY category, name');
    res.json(results || []);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rota raiz
app.get('/', (req, res) => {
  res.sendFile(join(__dirname, 'public', 'index.html'));
});

// Iniciar servidor
async function startServer() {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`
╔════════════════════════════════════════════════════════════╗
║   🌾 Sistema de Gestão de Estoque - Agroindústria        ║
║                                                            ║
║   ✅ Servidor rodando em: http://localhost:${PORT}        ║
║   📊 Banco de dados: MySQL                                ║
║   🔌 Host: ${process.env.DB_HOST || 'localhost'}                              ║
║   📦 Database: ${process.env.DB_NAME || 'agroindustria_db'}              ║
║                                                            ║
║   Abra o navegador e acesse: http://localhost:${PORT}     ║
╚════════════════════════════════════════════════════════════╝
      `);
    });
  } catch (error) {
    console.error('❌ Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

startServer();
